import { Link, createFileRoute } from '@tanstack/react-router'
import { formatPrice } from '@/lib/format'
import { getOrder } from '@/server/orders.functions'

export const Route = createFileRoute('/pedido/$orderId')({
  component: OrderConfirmation,
  loader: async ({ params }) => {
    const id = Number(params.orderId)
    return getOrder({ data: { id } })
  },
})

function OrderConfirmation() {
  const order = Route.useLoaderData()
  const turno = String(order.id).padStart(3, '0')

  return (
    <div className="max-w-lg mx-auto px-4 py-10">
      <div className="bg-white border-2 border-dashed border-gray-300 rounded-2xl p-8 shadow-sm print:shadow-none print:border-black">
        <div className="text-center mb-6">
          <p className="text-sm font-semibold text-gray-500 uppercase tracking-wide">
            Tu número de turno
          </p>
          <p className="text-6xl font-black text-[#C81D25] my-2">#{turno}</p>
          <p className="text-gray-500">
            Presenta este número al retirar tu pedido.
          </p>
        </div>

        <div className="border-t border-dashed border-gray-300 pt-4 mb-4 font-mono text-sm">
          <div className="flex justify-between mb-1">
            <span className="text-gray-500">Cliente</span>
            <span className="font-semibold">{order.customerName}</span>
          </div>
          <div className="flex justify-between mb-1">
            <span className="text-gray-500">Teléfono</span>
            <span className="font-semibold">{order.phone}</span>
          </div>
          <div className="flex justify-between mb-1">
            <span className="text-gray-500">Fecha</span>
            <span className="font-semibold">
              {order.createdAt
                ? new Date(order.createdAt).toLocaleString('es-EC')
                : '-'}
            </span>
          </div>
        </div>

        <ul className="border-t border-dashed border-gray-300 pt-4 mb-4 flex flex-col gap-1 font-mono text-sm">
          {order.items.map((item, i) => (
            <li key={i} className="flex justify-between">
              <span>
                {item.qty} x {item.name}
              </span>
              <span>{formatPrice(item.priceCents * item.qty)}</span>
            </li>
          ))}
        </ul>

        <div className="border-t border-dashed border-gray-300 pt-4 flex justify-between font-bold text-lg">
          <span>Total</span>
          <span>{formatPrice(order.totalCents)}</span>
        </div>
      </div>

      <div className="mt-6 bg-[#FFF3F0] border border-[#C81D25]/30 rounded-2xl p-6">
        {order.paymentMethod === 'efectivo' ? (
          <>
            <h2 className="font-bold text-[#2B1B12] mb-2">
              Pago en efectivo
            </h2>
            <p className="text-sm text-gray-600">
              Acércate a la caja de la tienda y paga en efectivo{' '}
              <strong>{formatPrice(order.totalCents)}</strong> al retirar tu
              pedido. Menciona tu número de turno{' '}
              <strong>#{turno}</strong>.
            </p>
          </>
        ) : (
          <>
            <h2 className="font-bold text-[#2B1B12] mb-2">
              Transferencia bancaria
            </h2>
            <p className="text-sm text-gray-600 mb-3">
              Realiza la transferencia por{' '}
              <strong>{formatPrice(order.totalCents)}</strong> a la siguiente
              cuenta e indica tu número de turno como referencia:
            </p>
            <div className="bg-white rounded-xl p-4 font-mono text-sm flex flex-col gap-1 mb-3">
              <div className="flex justify-between">
                <span className="text-gray-500">Banco</span>
                <span className="font-semibold">Banco Pichincha</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Tipo de cuenta</span>
                <span className="font-semibold">Ahorros</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Número</span>
                <span className="font-semibold">2203456789</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Titular</span>
                <span className="font-semibold">El Rey Crocante S.A.</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">RUC</span>
                <span className="font-semibold">1792345678001</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Referencia</span>
                <span className="font-semibold">Turno #{turno}</span>
              </div>
            </div>
            <p className="text-sm text-gray-600">
              Envía tu comprobante de pago por WhatsApp al{' '}
              <strong>+593 99 123 4567</strong> indicando tu número de turno.
              Prepararemos tu pedido en cuanto confirmemos el pago.
            </p>
          </>
        )}
      </div>

      <div className="mt-6 flex flex-col sm:flex-row gap-3 print:hidden">
        <button
          onClick={() => window.print()}
          className="flex-1 border border-gray-300 font-bold py-3 rounded-full hover:bg-gray-50 transition-colors"
        >
          Imprimir ticket
        </button>
        <Link
          to="/"
          className="flex-1 text-center bg-[#C81D25] text-white font-bold py-3 rounded-full hover:bg-[#a91620] transition-colors"
        >
          Volver al menú
        </Link>
      </div>
    </div>
  )
}
