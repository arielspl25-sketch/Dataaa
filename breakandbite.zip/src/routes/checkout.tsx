import { useState, type FormEvent } from 'react'
import { Link, createFileRoute, useNavigate } from '@tanstack/react-router'
import { useCart } from '@/lib/cart'
import { formatPrice } from '@/lib/format'
import { createOrder } from '@/server/orders.functions'

export const Route = createFileRoute('/checkout')({
  component: Checkout,
})

type PaymentMethod = 'efectivo' | 'transferencia'

function Checkout() {
  const { items, subtotalCents, clear } = useCart()
  const navigate = useNavigate()

  const [customerName, setCustomerName] = useState('')
  const [phone, setPhone] = useState('')
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('efectivo')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  if (items.length === 0) {
    return (
      <div className="max-w-lg mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl font-bold text-[#2B1B12] mb-3">
          Tu pedido está vacío
        </h1>
        <p className="text-gray-500 mb-6">
          Agrega productos del menú antes de continuar al pago.
        </p>
        <Link
          to="/"
          className="inline-block bg-[#C81D25] text-white font-bold px-6 py-3 rounded-full hover:bg-[#a91620] transition-colors"
        >
          Ver el menú
        </Link>
      </div>
    )
  }

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setError(null)
    setSubmitting(true)
    try {
      const order = await createOrder({
        data: {
          customerName: customerName.trim(),
          phone: phone.trim(),
          paymentMethod,
          items: items.map((item) => ({
            id: item.id,
            name: item.name,
            priceCents: item.priceCents,
            qty: item.qty,
          })),
        },
      })
      clear()
      navigate({ to: '/pedido/$orderId', params: { orderId: String(order.id) } })
    } catch (err) {
      console.error(err)
      setError('No se pudo generar tu turno. Intenta de nuevo.')
      setSubmitting(false)
    }
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-extrabold text-[#2B1B12] mb-8">
        Finalizar pedido
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-[1fr_320px] gap-8">
        <form onSubmit={handleSubmit} className="flex flex-col gap-6">
          <div className="bg-white border border-gray-200 rounded-2xl p-6">
            <h2 className="font-bold text-[#2B1B12] mb-4">Tus datos</h2>
            <div className="flex flex-col gap-4">
              <label className="flex flex-col gap-1">
                <span className="text-sm font-semibold text-gray-600">
                  Nombre completo
                </span>
                <input
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#C81D25]"
                  placeholder="Ej. María Pérez"
                />
              </label>
              <label className="flex flex-col gap-1">
                <span className="text-sm font-semibold text-gray-600">
                  Teléfono / WhatsApp
                </span>
                <input
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#C81D25]"
                  placeholder="Ej. 099 999 9999"
                />
              </label>
            </div>
          </div>

          <div className="bg-white border border-gray-200 rounded-2xl p-6">
            <h2 className="font-bold text-[#2B1B12] mb-4">Método de pago</h2>
            <p className="text-sm text-gray-500 mb-4">
              No se cobra nada en línea. Al confirmar recibirás un número de
              turno y las instrucciones para pagar tu pedido.
            </p>
            <div className="flex flex-col gap-3">
              <label
                className={`flex items-start gap-3 border rounded-xl p-4 cursor-pointer transition-colors ${
                  paymentMethod === 'efectivo'
                    ? 'border-[#C81D25] bg-[#FFF3F0]'
                    : 'border-gray-200'
                }`}
              >
                <input
                  type="radio"
                  name="paymentMethod"
                  value="efectivo"
                  checked={paymentMethod === 'efectivo'}
                  onChange={() => setPaymentMethod('efectivo')}
                  className="mt-1"
                />
                <span>
                  <span className="block font-semibold text-[#2B1B12]">
                    Efectivo
                  </span>
                  <span className="block text-sm text-gray-500">
                    Paga en caja cuando retires tu pedido.
                  </span>
                </span>
              </label>
              <label
                className={`flex items-start gap-3 border rounded-xl p-4 cursor-pointer transition-colors ${
                  paymentMethod === 'transferencia'
                    ? 'border-[#C81D25] bg-[#FFF3F0]'
                    : 'border-gray-200'
                }`}
              >
                <input
                  type="radio"
                  name="paymentMethod"
                  value="transferencia"
                  checked={paymentMethod === 'transferencia'}
                  onChange={() => setPaymentMethod('transferencia')}
                  className="mt-1"
                />
                <span>
                  <span className="block font-semibold text-[#2B1B12]">
                    Transferencia bancaria
                  </span>
                  <span className="block text-sm text-gray-500">
                    Recibirás los datos bancarios para transferir antes de
                    retirar tu pedido.
                  </span>
                </span>
              </label>
            </div>
          </div>

          {error && (
            <p className="text-[#C81D25] font-medium text-sm">{error}</p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="bg-[#C81D25] text-white font-bold py-3 rounded-full hover:bg-[#a91620] transition-colors disabled:opacity-60"
          >
            {submitting ? 'Generando turno...' : 'Generar mi ticket / turno'}
          </button>
        </form>

        <aside className="bg-white border border-gray-200 rounded-2xl p-6 h-fit">
          <h2 className="font-bold text-[#2B1B12] mb-4">Resumen</h2>
          <ul className="flex flex-col gap-3 mb-4">
            {items.map((item) => (
              <li key={item.id} className="flex justify-between text-sm">
                <span className="text-gray-600">
                  {item.qty} x {item.name}
                </span>
                <span className="font-semibold text-[#2B1B12]">
                  {formatPrice(item.priceCents * item.qty)}
                </span>
              </li>
            ))}
          </ul>
          <div className="border-t pt-4 flex justify-between font-bold text-[#2B1B12]">
            <span>Total</span>
            <span>{formatPrice(subtotalCents)}</span>
          </div>
        </aside>
      </div>
    </div>
  )
}
