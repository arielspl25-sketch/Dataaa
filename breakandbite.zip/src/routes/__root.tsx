import { HeadContent, Scripts, createRootRoute } from '@tanstack/react-router'
import { CartDrawer } from '@/components/CartDrawer'
import { Header } from '@/components/Header'
import { CartProvider } from '@/lib/cart'

import '../styles.css'

const siteName = 'El Rey Crocante'
const siteDescription =
  'Pide pollo crocante, combos y hamburguesas en línea. Genera tu turno y paga en efectivo o por transferencia al retirar.'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      {
        charSet: 'utf-8',
      },
      {
        name: 'viewport',
        content: 'width=device-width, initial-scale=1',
      },
      {
        title: siteName,
      },
      {
        name: 'description',
        content: siteDescription,
      },
      {
        property: 'og:title',
        content: siteName,
      },
      {
        property: 'og:description',
        content: siteDescription,
      },
      {
        property: 'og:type',
        content: 'website',
      },
      {
        name: 'twitter:card',
        content: 'summary_large_image',
      },
    ],
  }),
  shellComponent: RootDocument,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <head>
        <HeadContent />
      </head>
      <body>
        <CartProvider>
          <Header />
          {children}
          <CartDrawer />
        </CartProvider>
        <Scripts />
      </body>
    </html>
  )
}
