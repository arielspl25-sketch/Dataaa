import { createFileRoute } from '@tanstack/react-router'
import { categories } from '@/data/menu'
import menu from '@/data/menu'
import { MenuItemCard } from '@/components/MenuItemCard'
import { BRAND_NAME } from '@/components/Header'

export const Route = createFileRoute('/')({
  component: Home,
})

function Home() {
  return (
    <div>
      <section className="relative">
        <div className="w-full h-[420px] md:h-[520px] overflow-hidden">
          <img
            src="/.netlify/images?url=%2Fimg%2Fhero.jpg&w=1600&h=900&fit=cover&fm=webp"
            alt="Deliciosa comida de El Rey Crocante"
            className="w-full h-full object-cover brightness-[0.55]"
          />
        </div>
        <div className="absolute inset-0 flex items-center">
          <div className="max-w-6xl mx-auto px-4 w-full">
            <div className="max-w-lg text-white">
              <h1 className="text-4xl md:text-5xl font-extrabold mb-4 drop-shadow-lg">
                {BRAND_NAME}
              </h1>
              <p className="text-lg md:text-xl mb-6 drop-shadow">
                Pollo crocante, combos familiares y hamburguesas irresistibles.
                Pide en línea y retira tu turno para pagar en efectivo o por
                transferencia.
              </p>
              <a
                href="#menu"
                className="inline-block bg-[#F4B400] text-[#2B1B12] font-bold px-6 py-3 rounded-full hover:bg-[#e0a600] transition-colors"
              >
                Ver el menú
              </a>
            </div>
          </div>
        </div>
      </section>

      <nav className="sticky top-[57px] z-30 bg-white border-b overflow-x-auto">
        <div className="max-w-6xl mx-auto flex gap-2 px-4 py-3">
          {categories.map((cat) => (
            <a
              key={cat.slug}
              href={`#${cat.slug}`}
              className="whitespace-nowrap px-4 py-2 rounded-full border border-gray-200 text-sm font-semibold text-[#2B1B12] hover:bg-[#FFF3D6] hover:border-[#F4B400] transition-colors"
            >
              {cat.name}
            </a>
          ))}
        </div>
      </nav>

      <main id="menu" className="max-w-6xl mx-auto px-4 py-10">
        {categories.map((cat) => {
          const items = menu.filter((item) => item.category === cat.slug)
          if (items.length === 0) return null
          return (
            <section key={cat.slug} id={cat.slug} className="mb-14 scroll-mt-32">
              <h2 className="text-2xl font-extrabold text-[#2B1B12] mb-5 border-l-4 border-[#C81D25] pl-3">
                {cat.name}
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                {items.map((item) => (
                  <MenuItemCard key={item.id} item={item} />
                ))}
              </div>
            </section>
          )
        })}
      </main>

      <footer className="bg-[#2B1B12] text-white/80 py-8">
        <div className="max-w-6xl mx-auto px-4 text-sm flex flex-col gap-2">
          <p className="font-bold text-white">{BRAND_NAME}</p>
          <p>Retiro en tienda · Pago en efectivo o por transferencia bancaria</p>
          <p>Av. Principal y Secundaria, Quito, Ecuador · Lun a Dom 11:00 - 21:00</p>
        </div>
      </footer>
    </div>
  )
}
