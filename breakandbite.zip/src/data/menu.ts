export interface MenuItem {
  id: number
  category: string
  name: string
  description: string
  priceCents: number
  image: string
}

export interface Category {
  slug: string
  name: string
}

export const categories: Array<Category> = [
  { slug: 'combos', name: 'Combos' },
  { slug: 'pollo', name: 'Pollo' },
  { slug: 'hamburguesas', name: 'Hamburguesas' },
  { slug: 'acompanamientos', name: 'Acompañamientos' },
  { slug: 'bebidas', name: 'Bebidas' },
  { slug: 'postres', name: 'Postres' },
]

const menu: Array<MenuItem> = [
  {
    id: 1,
    category: 'combos',
    name: 'Combo Individual Crocante',
    description: '1 pieza de pollo crocante, papas fritas y bebida de 400ml.',
    priceCents: 650,
    image: '/img/combo-individual.jpg',
  },
  {
    id: 2,
    category: 'combos',
    name: 'Combo Doble Crocante',
    description: '2 piezas de pollo crocante, papas fritas grandes y bebida de 500ml.',
    priceCents: 890,
    image: '/img/combo-individual.jpg',
  },
  {
    id: 3,
    category: 'combos',
    name: 'Combo Familiar x8',
    description: '8 piezas de pollo, 2 papas grandes y 4 bebidas de 500ml. Ideal para compartir.',
    priceCents: 2490,
    image: '/img/combo-familiar.jpg',
  },
  {
    id: 4,
    category: 'combos',
    name: 'Combo Familiar x12',
    description: '12 piezas de pollo, 3 papas grandes y 6 bebidas de 500ml.',
    priceCents: 3490,
    image: '/img/combo-familiar.jpg',
  },
  {
    id: 5,
    category: 'pollo',
    name: 'Balde de Pollo x16',
    description: '16 piezas de pollo crocante, perfecto para reuniones grandes.',
    priceCents: 2990,
    image: '/img/balde-pollo.jpg',
  },
  {
    id: 6,
    category: 'pollo',
    name: 'Piezas de Pollo x4',
    description: '4 piezas de pollo crocante, receta original.',
    priceCents: 950,
    image: '/img/piezas-broaster.jpg',
  },
  {
    id: 7,
    category: 'pollo',
    name: 'Piezas de Pollo x8',
    description: '8 piezas de pollo crocante, receta original.',
    priceCents: 1790,
    image: '/img/piezas-broaster.jpg',
  },
  {
    id: 8,
    category: 'pollo',
    name: 'Pollo Broaster x6',
    description: '6 piezas de pollo estilo broaster, jugoso por dentro y crocante por fuera.',
    priceCents: 1590,
    image: '/img/piezas-broaster.jpg',
  },
  {
    id: 9,
    category: 'hamburguesas',
    name: 'Hamburguesa Crocante Clásica',
    description: 'Filete de pollo crocante, lechuga, tomate y mayonesa en pan brioche.',
    priceCents: 550,
    image: '/img/hamburguesa.jpg',
  },
  {
    id: 10,
    category: 'hamburguesas',
    name: 'Hamburguesa Crocante BBQ',
    description: 'Filete de pollo crocante, salsa BBQ, queso cheddar y cebolla crispy.',
    priceCents: 620,
    image: '/img/hamburguesa.jpg',
  },
  {
    id: 11,
    category: 'acompanamientos',
    name: 'Papas Fritas Grandes',
    description: 'Porción grande de papas fritas doradas y crocantes.',
    priceCents: 250,
    image: '/img/papas-fritas.jpg',
  },
  {
    id: 12,
    category: 'acompanamientos',
    name: 'Papas Fritas Medianas',
    description: 'Porción mediana de papas fritas doradas y crocantes.',
    priceCents: 180,
    image: '/img/papas-fritas.jpg',
  },
  {
    id: 13,
    category: 'bebidas',
    name: 'Gaseosa 500ml',
    description: 'Bebida gaseosa bien fría, sabor a elección.',
    priceCents: 150,
    image: '/img/bebida.jpg',
  },
  {
    id: 14,
    category: 'postres',
    name: 'Postre Manzana Crocante',
    description: 'Empanada crocante rellena de manzana, espolvoreada con azúcar.',
    priceCents: 220,
    image: '/img/postre.jpg',
  },
]

export default menu
