import { Link } from '@tanstack/react-router'
import { Minus, Plus, ShoppingBag, Trash2, X } from 'lucide-react'
import { useCart } from '@/lib/cart'
import { formatPrice } from '@/lib/format'

export function CartDrawer() {
  const { items, isCartOpen, closeCart, updateQty, removeItem, subtotalCents } =
    useCart()

  if (!isCartOpen) return null

  return (
    <div className="fixed inset-0 z-50">
      <div
        className="absolute inset-0 bg-black/50"
        onClick={closeCart}
        aria-hidden="true"
      />
      <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-2xl flex flex-col">
        <div className="flex items-center justify-between px-5 py-4 border-b">
          <h2 className="text-xl font-bold text-[#2B1B12]">Mi pedido</h2>
          <button
            onClick={closeCart}
            aria-label="Cerrar carrito"
            className="text-gray-500 hover:text-gray-800"
          >
            <X size={24} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center text-gray-500 gap-3">
              <ShoppingBag size={48} className="text-gray-300" />
              <p>Tu pedido está vacío.</p>
              <p className="text-sm">Agrega algo delicioso del menú.</p>
            </div>
          ) : (
            <ul className="flex flex-col gap-4">
              {items.map((item) => (
                <li
                  key={item.id}
                  className="flex items-center justify-between gap-3"
                >
                  <div className="flex-1">
                    <p className="font-semibold text-[#2B1B12]">{item.name}</p>
                    <p className="text-sm text-gray-500">
                      {formatPrice(item.priceCents)} c/u
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => updateQty(item.id, item.qty - 1)}
                      className="w-7 h-7 flex items-center justify-center rounded-full border border-gray-300 hover:bg-gray-100"
                      aria-label="Restar"
                    >
                      <Minus size={14} />
                    </button>
                    <span className="w-6 text-center font-medium">
                      {item.qty}
                    </span>
                    <button
                      onClick={() => updateQty(item.id, item.qty + 1)}
                      className="w-7 h-7 flex items-center justify-center rounded-full border border-gray-300 hover:bg-gray-100"
                      aria-label="Sumar"
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                  <p className="w-16 text-right font-semibold text-[#2B1B12]">
                    {formatPrice(item.priceCents * item.qty)}
                  </p>
                  <button
                    onClick={() => removeItem(item.id)}
                    aria-label="Eliminar"
                    className="text-gray-400 hover:text-[#C81D25]"
                  >
                    <Trash2 size={16} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {items.length > 0 && (
          <div className="border-t px-5 py-4">
            <div className="flex items-center justify-between mb-4">
              <span className="font-semibold text-gray-600">Subtotal</span>
              <span className="text-xl font-bold text-[#2B1B12]">
                {formatPrice(subtotalCents)}
              </span>
            </div>
            <Link
              to="/checkout"
              onClick={closeCart}
              className="block text-center bg-[#C81D25] text-white font-bold py-3 rounded-full hover:bg-[#a91620] transition-colors"
            >
              Continuar al pago
            </Link>
          </div>
        )}
      </div>
    </div>
  )
}
