import { Minus, Plus } from 'lucide-react'
import { useCart } from '@/lib/cart'
import { formatPrice } from '@/lib/format'
import type { MenuItem } from '@/data/menu'

export function MenuItemCard({ item }: { item: MenuItem }) {
  const { qtyFor, addItem, updateQty } = useCart()
  const qty = qtyFor(item.id)

  return (
    <div className="flex flex-col bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <div className="aspect-[4/3] w-full overflow-hidden bg-gray-100">
        <img
          src={`/.netlify/images?url=${encodeURIComponent(item.image)}&w=480&h=360&fit=cover&fm=webp`}
          alt={item.name}
          className="w-full h-full object-cover"
          loading="lazy"
        />
      </div>
      <div className="flex flex-col flex-1 p-4">
        <h3 className="font-bold text-[#2B1B12] mb-1">{item.name}</h3>
        <p className="text-sm text-gray-500 flex-1 mb-3">{item.description}</p>
        <div className="flex items-center justify-between">
          <span className="text-lg font-extrabold text-[#C81D25]">
            {formatPrice(item.priceCents)}
          </span>
          {qty === 0 ? (
            <button
              onClick={() =>
                addItem({
                  id: item.id,
                  name: item.name,
                  priceCents: item.priceCents,
                })
              }
              className="bg-[#F4B400] text-[#2B1B12] font-bold px-4 py-2 rounded-full hover:bg-[#e0a600] transition-colors"
            >
              Agregar
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => updateQty(item.id, qty - 1)}
                className="w-8 h-8 flex items-center justify-center rounded-full border border-gray-300 hover:bg-gray-100"
                aria-label="Restar"
              >
                <Minus size={16} />
              </button>
              <span className="w-6 text-center font-bold">{qty}</span>
              <button
                onClick={() => updateQty(item.id, qty + 1)}
                className="w-8 h-8 flex items-center justify-center rounded-full border border-gray-300 hover:bg-gray-100"
                aria-label="Sumar"
              >
                <Plus size={16} />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
