import { Link } from '@tanstack/react-router'
import { ShoppingCart } from 'lucide-react'
import { useCart } from '@/lib/cart'

const BRAND_NAME = 'El Rey Crocante'

export function Header() {
  const { count, toggleCart } = useCart()

  return (
    <header className="sticky top-0 z-40 bg-[#C81D25] text-white shadow-md">
      <div className="max-w-6xl mx-auto flex items-center justify-between px-4 py-3">
        <Link to="/" className="flex items-center gap-2">
          <span className="text-2xl">🍗</span>
          <span className="font-extrabold text-lg leading-tight tracking-tight">
            {BRAND_NAME}
          </span>
        </Link>

        <button
          onClick={toggleCart}
          className="relative flex items-center gap-2 bg-white text-[#C81D25] font-bold px-4 py-2 rounded-full hover:bg-[#FFF3D6] transition-colors"
          aria-label="Ver carrito"
        >
          <ShoppingCart size={20} />
          <span className="hidden sm:inline">Mi pedido</span>
          {count > 0 && (
            <span className="absolute -top-2 -right-2 bg-[#F4B400] text-[#2B1B12] text-xs font-bold rounded-full w-6 h-6 flex items-center justify-center border-2 border-white">
              {count}
            </span>
          )}
        </button>
      </div>
    </header>
  )
}

export { BRAND_NAME }
