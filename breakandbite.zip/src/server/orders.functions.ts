import { createServerFn } from '@tanstack/react-start'
import { eq } from 'drizzle-orm'
import { z } from 'zod'
import { db } from '../../db/index.js'
import { orders } from '../../db/schema.js'

const OrderItemSchema = z.object({
  id: z.number(),
  name: z.string(),
  priceCents: z.number().int().positive(),
  qty: z.number().int().positive(),
})

const CreateOrderSchema = z.object({
  customerName: z.string().min(1).max(120),
  phone: z.string().min(1).max(30),
  paymentMethod: z.enum(['efectivo', 'transferencia']),
  items: z.array(OrderItemSchema).min(1),
})

export const createOrder = createServerFn({ method: 'POST' })
  .inputValidator(CreateOrderSchema)
  .handler(async ({ data }) => {
    const totalCents = data.items.reduce(
      (sum, item) => sum + item.priceCents * item.qty,
      0,
    )

    const [order] = await db
      .insert(orders)
      .values({
        customerName: data.customerName,
        phone: data.phone,
        paymentMethod: data.paymentMethod,
        items: data.items,
        totalCents,
      })
      .returning()

    return order
  })

export const getOrder = createServerFn({ method: 'GET' })
  .inputValidator((data: { id: number }) => data)
  .handler(async ({ data }) => {
    const [order] = await db
      .select()
      .from(orders)
      .where(eq(orders.id, data.id))

    if (!order) {
      throw new Error('Pedido no encontrado')
    }

    return order
  })
