import { pgTable, serial, text, integer, jsonb, timestamp } from 'drizzle-orm/pg-core'

export interface OrderItem {
  id: number
  name: string
  priceCents: number
  qty: number
}

export const orders = pgTable('orders', {
  id: serial().primaryKey(),
  customerName: text('customer_name').notNull(),
  phone: text('phone').notNull(),
  paymentMethod: text('payment_method').notNull(),
  items: jsonb('items').$type<Array<OrderItem>>().notNull(),
  totalCents: integer('total_cents').notNull(),
  status: text('status').notNull().default('pendiente'),
  createdAt: timestamp('created_at').defaultNow(),
})
